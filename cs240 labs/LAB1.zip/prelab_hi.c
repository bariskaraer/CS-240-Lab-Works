	// In a high-level language, this is what we want to do
  min = x;	
	if(x > y)
    min = y;

