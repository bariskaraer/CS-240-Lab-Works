	// In a high-level language, this is what we want to do
  max = x;	
	if(y > x)
    max = y;
	if(z > max)
		max=z;
	if(g>max)
		max=g

